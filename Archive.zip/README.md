# Destiny-Report-Extension

This is an extension from  [Destiny.report](https://destiny.report) for Bungie.net fireteams to show players stats


<br/>
  
# Notice
<aside class="notice">
This is a fan made extension
</aside>

